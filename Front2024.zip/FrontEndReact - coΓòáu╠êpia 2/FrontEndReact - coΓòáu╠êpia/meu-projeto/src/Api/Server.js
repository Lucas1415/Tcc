const express = require('express');
const app = express();
const PORT = 3000;

// Middleware para permitir JSON no body
app.use(express.json());

// Simulação de um banco de dados em memória
const usersDb = [
    { email: "user1@example.com", password: "password123" },
    { email: "user2@example.com", password: "password456" }
];

// Função de validação de token simulada (exemplo simples)
const validateToken = (token) => {
    // Implementação fictícia, apenas para exemplificar
    return token === "valid_token";
};

// Rota GET para verificar o token e retornar o usuário associado
app.get('/api/user', (req, res) => {
    const token = req.headers['authorization'];

    if (!token || !validateToken(token)) {
        return res.status(401).json({ message: "Token inválido ou ausente" });
    }

    // Retorna um usuário fictício para simulação
    const user = { email: "user1@example.com" }; // Dados do usuário autenticado
    res.json({ user });
});

// Rota GET para listar todos os usuários (exemplo de rota protegida)
app.get('/api/users', (req, res) => {
    const token = req.headers['authorization'];

    if (!token || !validateToken(token)) {
        return res.status(401).json({ message: "Token inválido ou ausente" });
    }

    res.json(usersDb);
});

// Rota de verificação de token para autenticação (usada no useEffect)
app.post('/api/verify-token', (req, res) => {
    const { token } = req.body;

    if (!validateToken(token)) {
        return res.status(401).json({ message: "Token inválido" });
    }

    // Retorna um usuário fictício associado ao token para simulação
    const user = { email: "user1@example.com" };
    res.json({ user });
});

// Rota POST para login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const user = usersDb.find(u => u.email === email && u.password === password);

    if (user) {
        const token = "valid_token"; // Gerar um token seguro aqui
        res.json({ user, token });
    } else {
        res.status(401).json({ message: "E-mail ou senha incorretos" });
    }
});

// Rota POST para cadastro
app.post('/api/register', (req, res) => {
    const { email, password } = req.body;
    const userExists = usersDb.some(u => u.email === email);

    if (userExists) {
        return res.status(400).json({ message: "Usuário já cadastrado" });
    }

    usersDb.push({ email, password });
    res.status(201).json({ message: "Usuário registrado com sucesso" });
});

// Inicia o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
