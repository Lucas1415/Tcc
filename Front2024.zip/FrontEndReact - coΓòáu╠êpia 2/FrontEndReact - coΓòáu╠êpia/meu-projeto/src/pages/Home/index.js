// src/pages/Carrossel/index.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import * as C from "./style";
import Logo_top from '../Home/Logo_top.jpeg';
import useAuth from '../../hooks/useAuth';
import Button from '../../components/Button';
import  ImageClube  from './ImageClube.jpg';

const Home = () => {
    const { signout, user } = useAuth();
    const navigate = useNavigate();

    const handleSignout = () => {
        signout();
        navigate('/');
    };

    return (
        <C.MenuContainer>
            <C.Menu>
                <C.MenuItem>
                    <C.Logo>
                        <img src={Logo_top} alt="Logo" />
                    </C.Logo>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/home">Home</Link>
                </C.MenuItem>
                <C.MenuItem>
                    <C.DropdownTrigger>
                        <Link>Semana</Link>
                        <C.DropdownContent>
                            <Link to="/Segunda">Segunda</Link>
                            <Link to="/Terca">Terça</Link>
                            <Link to="/Quarta">Quarta</Link>
                            <Link to="/Quinta">Quinta</Link>
                            <Link to="/Sexta">Sexta</Link>
                            <Link to="/Sabado">Sábado</Link>
                            <Link to="/Domingo">Domingo</Link>
                        </C.DropdownContent>
                    </C.DropdownTrigger>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/Cuidador">Cuidador</Link>
                </C.MenuItem>
                <C.MenuItem>
                    {!user ? (
                        <Button Text="Login" onClick={() => navigate('/Signin')} />
                    ) : (
                        <Button Text="Sair" onClick={handleSignout} />
                    )}
                </C.MenuItem>
            </C.Menu>
            <C.Container>
            <C.Title>
                Bem Vindos ao Memory Keys
            </C.Title>
            <C.Subtitle>
               Ajudando Você a Cuidar
            </C.Subtitle>
            <C.CaixaText>
       <C.TableText>
            <C.Texto>
             Nosso site é direcionado para todos os cuidadores <br></br>
             que precisam de ajuda no cuidado com pessoas que tem alzheimer
            </C.Texto>
            </C.TableText>
            <C.TableText2>
                <C.Titulo>
                O que é o Alzheimer?
                </C.Titulo>
                <C.Texto>
           
             O alzheimer é uma doença que afeta principalmente a memória <br></br>
             e também, as funções cognitivas do paciênte<br></br>
                </C.Texto>
                <C.MicroText>
                    Saiba como ajudar na aba do cuidador
                </C.MicroText>
            </C.TableText2>
            </C.CaixaText>
            </C.Container>
            <C.aboutSection>
                <C.aboutText>
                    <C.SubTitle>
                        Quem Somos
                    </C.SubTitle>
                    <C.Text>
                        Somos alunos do Colégio Técnico da Unicamp, na qual cursamos Desenvolvimento de Sistemas
                        e buscamos em nosso TCC criar um site na qual pudessemos ajudar aqueles que possuiem em suas residencia
                        algum idoso que possua Alzheimer, então assim buscamops noas aprofundar no assunto e buscar possiveis 
                        formas de ajudar há aqueles cuidadores.
                    </C.Text>
                </C.aboutText>
                <C.aboutImage>
                <img src={ImageClube} alt="image" />
                </C.aboutImage>
            </C.aboutSection>
       
         <C.FooterContainer>
         <C.FooterText>
             © 2024 Memory Keys - Todos os direitos reservados
         </C.FooterText>
         <C.FooterIcons>
             <C.FooterLink href="#">Facebook</C.FooterLink>
             <C.FooterLink href="#">Instagram</C.FooterLink>
             <C.FooterLink href="#">Twitter</C.FooterLink>
         </C.FooterIcons>
     </C.FooterContainer>
 </C.MenuContainer>
    );
};

export default Home;
