import React, { useEffect, useState } from "react";
import api from "./Api/Api";
import { AuthProvider } from './contexts/auth'; // Importando o AuthProvider
import RouterApp from './routes';
import GlobalStyle from './global';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './App.css';

const App = () => {
  const [user, setUser] = useState();

  useEffect(() => {
    api
      .get("/usuario/romulo27") // Substitua pelo usuário desejado
      .then(response => setUser(response.data))
      .catch(err => {
        console.error("Ops! Ocorreu um erro: " + err);
      });
  }, []);

  return (
    <AuthProvider>
      <div className="App">
        <p>Usuário: {user?.login}</p>
        <p>Biografia: {user?.bio}</p>
      </div>
      <RouterApp />
      <GlobalStyle />
    </AuthProvider>
  );
};

export default App;
