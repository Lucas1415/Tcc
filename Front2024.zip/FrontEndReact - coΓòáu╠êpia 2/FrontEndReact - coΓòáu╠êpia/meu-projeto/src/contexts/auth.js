import React, { createContext, useEffect, useState } from 'react';

export const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [errorMessage, setErrorMessage] = useState(null);

    useEffect(() => {
        const userToken = localStorage.getItem("user_token");

        if (userToken) {
            fetch('/api/verify-token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: userToken })
            })
            .then(response => response.json())
            .then(data => {
                if (data.user) {
                    setUser(data.user);
                } else {
                    localStorage.removeItem("user_token");
                }
            })
            .catch(error => console.error("Erro ao verificar token:", error));
        }
    }, []);

    const signin = async (email, password) => {
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                const { user, token } = data;
                localStorage.setItem("user_token", token);
                setUser(user);
            } else {
                setErrorMessage(data.message || "E-mail ou senha incorretos");
            }
        } catch (error) {
            console.error("Erro ao tentar fazer login:", error);
            setErrorMessage("Erro ao tentar fazer login");
        }
    };

    const signup = async (email, password) => {
        // Similar ao signin, adicione a manipulação de erros aqui
    };

    const signout = () => {
        setUser(null);
        localStorage.removeItem("user_token");
    };

    return (
        <AuthContext.Provider value={{ user, signed: !!user, signin, signup, signout }}>
            {children}
            {errorMessage && <div>{errorMessage}</div>} {/* Renderiza a mensagem de erro se existir */}
        </AuthContext.Provider>
    );
};
