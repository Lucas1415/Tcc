import React from 'react';
import { Table, TableHeader, TableCell } from './style';
import { Link } from 'react-router-dom';

const daysOfWeek = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
const daysText = [ 'Visita a um lugar conhecido: Passeio até um local familiar, como uma igreja, praça ou museu.',
 'Caminhada ao ar livre: 20-30 minutos de caminhada em um parque ou jardim para aproveitar o ar fresco e a natureza.',
  'Alongamento leve: Faça uma série de alongamentos suaves para manter a flexibilidade e a mobilidade.',
   'Jardinagem simples: Plantar flores ou cuidar de plantas em vasos, mexendo com a terra.',
    'Yoga suave ou Tai Chi: Movimentos lentos e controlados para melhorar o equilíbrio e a serenidade.',
     'Exercícios de coordenação motora fina: Usar blocos de montar ou enfiar contas em um fio.',
      'Sessão de dança: Dançar ao som de músicas antigas, movendo-se livremente.'];
const daysText2 = ['Pintura com esponja ou pincel: Usar esponjas ou pincéis grandes para pintar em telas ou papel.',
'Jogo de memória simples: Use cartas ou objetos familiares para um jogo de memória com poucos pares.',
'Atividade de arte: Pintura com aquarelas ou colorir em um livro de colorir para adultos.',
'Quebra-cabeça de poucas peças: Um quebra-cabeça com peças grandes e poucas peças para manter a mente ativa.',
'Trabalho com argila: Modelar figuras simples usando argila para estimular a criatividade e a coordenação motora.',
'Leitura de jornal ou revista: Ler artigos simples e conversar sobre as notícias.',
'Culinária assistida: Preparar uma receita simples, como fazer sanduíches ou biscoitos.'];

const daysText3 = ['Terapia com animais: Interação com animais de estimação, como cães ou gatos, para trazer conforto e alegria.',
'Hora da música: Ouça músicas antigas e cante junto com músicas que a pessoa gosta e lembra.',
'Leitura em voz alta: Ler uma história curta ou um poema, focando em textos que tragam boas lembranças.',
'Sessão de fotos antigas: Revisitar álbuns de fotos e conversar sobre as memórias associadas.',
'Assistir a filmes ou séries antigas: Escolha filmes ou séries de TV que a pessoa assistia e gostava no passado.',
'Jogos de tabuleiro simples: Jogos como bingo ou dominó, adaptados para serem mais simples e acessíveis.',
'Contação de histórias: Incentivar a pessoa a contar histórias de sua infância ou juventude.'];

const WeekTable = () => {
  console.log("WeekTable renderizzado")
  return (
    <Table>
      <thead>
        <tr>
          {daysOfWeek.map(day => (
          
            <TableHeader key={day}>{day}</TableHeader>
          ))}
        </tr>
      </thead>
      <tbody>
        <tr>
          {daysText.map(day => (
            <TableCell key={day}>{day}</TableCell>
          ))}
        </tr>
      </tbody>
      <tbody>
        <tr>
          {daysText2.map(day => (
            <TableCell key={day}>{day}</TableCell>
          ))}
        </tr>
      </tbody>
      <tbody>
        <tr>
          {daysText3.map(day => (
            <TableCell key={day}>{day}</TableCell>
          ))}
        </tr>
      </tbody>
    </Table>
  );
};

export default WeekTable;
