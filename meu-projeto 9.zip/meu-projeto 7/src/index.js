import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));

const addTidioScript = () => {
  const script = document.createElement('script');
  script.src = "//code.tidio.co/7d5krcbcz0g5bfz4ebh0irgo2rnirhnt.js";
  script.async = true; // Garante que o script não bloqueie a renderização
  document.body.appendChild(script);
};

addTidioScript(); // Adiciona o script quando a aplicação for carregada

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
