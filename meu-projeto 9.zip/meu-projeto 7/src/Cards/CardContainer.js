import React from 'react';
import Card from './Card';
import { Container } from './style';  // Importação correta
import imgJogo from '../images/imageJogo.jpg';
import imgCaminhada from '../images/imgCaminhada1.jpg';
import imgPasseio from '../images/imgPasseio1.jpg';

const CardContainer = () => {
  return (
    <Container>
      <Card 
       imageSrc= '../images/imageJogo.jpg'
        title="Jogos" 
        description="Jogo da Memória com fotos antigas (use fotos familiares ou de lugares que a pessoa conheça." 
      />
      <Card 
         imageSrc="../images/imgCaminhada1.jpg"
        title="Atividade" 
        description="Jardinagem simples (como regar plantas ou plantar flores)" 
      />
      <Card 
        imageSrc="../images/imgPasseio1.jpg" 
        title="Passseio" 
        description="Realizar passeios ao parque da cidade" 
      />
    </Container>
  );
};

export default CardContainer;