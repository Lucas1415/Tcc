import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion'; // Para animações (opcional)
import './stilo.css'; // Estilo personalizado
import * as C from './style'; // Estilos CSS-in-JS
import Logo_top from '../Home/Logo_top.jpeg';
import useAuth from '../../hooks/useAuth';
import Button from '../../components/Button';
import ImageClube from './ImageClube.jpg';
import image1 from '../../images/img1.jpg';
import image2 from '../../images/img2.jpg';
import image3 from '../../images/img3.jpg';
import image4 from '../../images/img4.jpg';

const Home = () => {
    const { signout, user } = useAuth();
    const navigate = useNavigate();
    const [textos, setTextos] = useState([]);
    const images = [image1, image2, image3, image4]; // Lista de imagens para o carrossel
    const [currentIndex, setCurrentIndex] = useState(0);
    

    // Função de logout
    const handleSignout = () => {
        signout();
        navigate('/');
    };

    // Função para avançar o carrossel
    const nextSlide = () => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    };

    // Função para voltar no carrossel
    const prevSlide = () => {
        setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
    };

    // Fetch de textos da API
    useEffect(() => {
        const fetchTextos = async () => {
            try {
                const response = await fetch("http://localhost:8080/texto/textos");
                const data = await response.json();
                setTextos(data); // Armazena os textos recebidos da API
            } catch (error) {
                console.error("Erro ao buscar textos:", error);
            }
        };

        fetchTextos(); // Carrega os textos ao inicializar o componente
    }, []);

    // Função para pegar texto baseado no tipo
    const getTextByType = (tipo) => {
        if (textos.length > 0) {
            const texto = textos[3]; // Assumindo que há apenas um objeto na resposta
            return texto[tipo] || '';
        }
        return ''; // Retorna vazio se não encontrar textos
    };

    return (
        <C.MenuContainer>
            {/* Menu */}
            <C.Menu>
                <C.MenuItem>
                    <C.Logo>
                        <img src={Logo_top} alt="Logo" />
                    </C.Logo>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/home">Home</Link>
                </C.MenuItem>
                <C.MenuItem>
                    <C.DropdownTrigger>
                        <Link>Semana</Link>
                        <C.DropdownContent>
                            <Link to="/Segunda">Segunda</Link>
                            <Link to="/Terca">Terça</Link>
                            <Link to="/Quarta">Quarta</Link>
                            <Link to="/Quinta">Quinta</Link>
                            <Link to="/Sexta">Sexta</Link>
                            <Link to="/Sabado">Sábado</Link>
                            <Link to="/Domingo">Domingo</Link>
                        </C.DropdownContent>
                    </C.DropdownTrigger>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/Cuidador">Cuidador</Link>
                </C.MenuItem>
                <C.MenuItem>
                    {!user ? (
                        <Button Text="Login" onClick={() => navigate('/Signin')} />
                    ) : (
                        <Button Text="Sair" onClick={handleSignout} />
                    )}
                </C.MenuItem>
            </C.Menu>
            <C.Carousel>
  <C.PrevButton onClick={prevSlide}>◀</C.PrevButton>
  <div>
    <C.SlideImage src={images[currentIndex]} alt={`Slide ${currentIndex + 1}`} />
  </div>
  <C.NextButton onClick={nextSlide}>▶</C.NextButton>
</C.Carousel>

            {/* Conteúdo Principal */}
            <C.Container>
                
                <C.Title>{getTextByType("titulo2")}</C.Title> {/* Subtítulo */}
                <C.Subtitle>{getTextByType("subtitulo")}</C.Subtitle>
                <C.CaixaText>
                    <C.TableText>
                        <C.Texto>{getTextByType("descricao")}</C.Texto>
                    </C.TableText>
                    <C.TableText2>
                        <C.Titulo>{getTextByType("titulo2")}</C.Titulo>
                        <C.Texto>{getTextByType("descricao2")}</C.Texto>
                        <C.MicroText>{getTextByType("microtexto")}</C.MicroText>
                    </C.TableText2>
                </C.CaixaText>
            </C.Container>

            {/* Carrossel de Imagens */}
        

            {/* Seção "Sobre" */}
            <C.aboutSection>
                <C.aboutText>
                    <C.SubTitle>{getTextByType("quemSomosTitulo")}</C.SubTitle>
                    <C.Text>{getTextByType("quemSomosDescricao")}</C.Text>
                </C.aboutText>
                <C.aboutImage>
                    <img src={ImageClube} alt="Clube" />
                </C.aboutImage>
            </C.aboutSection>

            {/* Rodapé */}
            <C.FooterContainer>
                <C.FooterText>{getTextByType("rodape")}</C.FooterText>
                <C.FooterIcons>
                    <C.FooterLink href="#">Facebook</C.FooterLink>
                    <C.FooterLink href="#">Instagram</C.FooterLink>
                    <C.FooterLink href="#">Twitter</C.FooterLink>
                </C.FooterIcons>
            </C.FooterContainer>
        </C.MenuContainer>
    );
};

export default Home;
