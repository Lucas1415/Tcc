// src/pages/style.js
import styled from 'styled-components';

export const aboutSection = styled.div`
display: flex;
justify-content: space-between;
align-items: center;
padding: 40px;
background-color:#C8a2c8;
border-radius: 8px;
box-shadow: 0 4px 8px rgba(0,0,00 0.1);
margin: 20px
`;
// Texto Principal e Secundário
export const MainText = styled.h1`
    font-size: 2rem;
    color: #4B0082; /* Roxo escuro */
    text-align: center;
    margin-bottom: 20px;
`;

export const SecondaryText = styled.h2`
    font-size: 1.5rem;
    color: #800080; /* Roxo */
    text-align: center;
    margin-bottom: 15px;
`;

// Botão personalizado
export const CustomButton = styled.button`
    background-color: #800080; /* Roxo */
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    padding: 10px 20px;
    cursor: pointer;
    margin: 10px;

    &:hover {
        background-color: #4B0082; /* Roxo escuro */
    }
`;
export const CarouselButton = styled.button`
  position: absolute;
  top: 50%;
  transform: translateY(-50%); /* Centraliza verticalmente o botão */
  background: rgba(255, 255, 255, 0.5); /* Fundo transparente branco */
  border: none;
  color: #800080; /* Cor do texto (roxo) */
  font-size: 2rem; /* Tamanho da fonte */
  padding: 10px;
  border-radius: 50%; /* Torna o botão arredondado */
  cursor: pointer;
  z-index: 10; /* Garante que o botão fique acima das imagens */
  opacity: 0.8; /* Opacidade para o efeito de transparência */

  &:hover {
    opacity: 1; /* Torna o botão totalmente visível ao passar o mouse */
    background: rgba(255, 255, 255, 0.8); /* Aumenta a opacidade do fundo */
  }

  &:focus {
    outline: none; /* Remove o contorno do botão ao focar */
  }
`;

export const PrevButton = styled(CarouselButton)`
  left: 20px; /* Botão à esquerda */
`;

export const NextButton = styled(CarouselButton)`
  right: 20px; /* Botão à direita */
`;

// Carousel (se necessário)
export const Carousel = styled.div`
  position: relative;
  display: flex;
  margin-top:-90px;
  justify-content: center;
  align-items: center;
  width: 100vw; /* Ocupa toda a largura da tela */
  height: 600px; /* Define uma altura fixa */
  overflow: hidden; /* Esconde qualquer conteúdo excedente */
`;

export const SlideImage = styled.img`
  width: 100vw; /* Ajusta a largura ao tamanho da tela */
  height: 100%; /* Garante que a altura ocupe todo o espaço do carrossel */
  object-fit: cover; /* Ajusta a imagem para cobrir o container sem distorção */
  display: block;
`;


export const CarouselItem = styled.div`
    flex: none;
    width: 100%;
    height: 100%;
    scroll-snap-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #E6E6FA; /* Fundo lilás */
`;

// Adicionar Padding Geral
export const PagePadding = styled.div`
    padding: 20px;
`;

// Título no Rodapé
export const FooterTitle = styled.h3`
    font-size: 1rem;
    color: #E6E6FA;
    margin-bottom: 10px;
`;


export const aboutText = styled.div`
max-width: 50%;
`;

export const SubTitle = styled.h2`
color:#2b2b2b;
`;

export const Text = styled.p`
color: #555;
line-height: 1.6;
`;
export const Container = styled.div`
margin-top: 450px;
align-items:center;
border-radius: 8px;
`;

export const aboutImage = styled.div`
  max-width: 800px; /* Limita a largura máxima do contêiner */
  height: 500px; /* Limita a altura máxima do contêiner */
  margin-left: 20px; /* Adiciona margem à esquerda */
  overflow: hidden; /* Garante que o conteúdo que ultrapassa o contêiner seja cortado */
`;

export const ImageClube = styled.img`
  width: 100%; /* Ajusta automaticamente à largura do contêiner */
  height: 100%; /* Ajusta automaticamente à altura do contêiner */
  object-fit: cover; /* Corta a imagem para se ajustar ao contêiner */
  border-radius: 8px; /* Aplica bordas arredondadas */
`;



export const MenuContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  background: linear-gradient(to bottom, #E6E6FA, #800080); /* Degradê do lilás ao roxo */
  min-height: 100vh; /* Garante que o fundo cubra toda a altura da tela */
  padding-top: 200px; /* Adiciona espaçamento no topo para acomodar o logo e o menu */
`;
export const Title = styled.h1`
    color: Purple; 
    font-size: 50px; // Tamanho da fonte
    text-align: center; // Alinhamento central
    margin-top: -300px; // Espaçamento acima do título
    margin-bottom: 20px; // Espaçamento abaixo do título
    font-family: 'Arial', sans-serif; // Fonte personalizada, ajuste conforme necessário
    rotetion: -30;s
    `;
    export const Subtitle = styled.h2`
    font-size: 1.5rem; // Ajuste o tamanho conforme necessário
    color: light-purple; // Cor do subtítulo
    text-align: center; // Centralizar, se desejado
    margin-top: 0.5rem; // Margem para espaçamento
`;
export const Texto = styled.h3`

    
    font-size: 20px; // Ajuste o tamanho conforme necessário
    color: light-purple; // Cor do subtítulo
    text-align: center; // Centralizar, se desejado
    margin-top: 1rem; // Margem para espaçamento
`;
export const Titulo = styled.h3`

    
    font-size: 25px; // Ajuste o tamanho conforme necessário
    color: light-purple; // Cor do subtítulo
    text-align: center; // Centralizar, se desejado
    margin-top: 1rem; // Margem para espaçamento
`;
export const CaixaText = styled.div`
    margin-top: 50px;
    display: flex;
    flex-direction: row; // Para alinhar horizontalmente
    gap: 1rem; // Espaçamento entre os itens
    justify-content: space-between; // Pode ajustar conforme necessário
`;

export const TableText = styled.div`
background-color: rgba(126, 0, 126, 0.2);

`;
export const TableText2 = styled.div`
background-color: rgba(126, 0, 126, 0.2);

`;

export const MicroText = styled.p`
font-size: 20px; // Ajuste o tamanho conforme necessário
color: black; // Cor do subtítulo
text-align: right; // Centralizar, se desejado
margin-top: 1rem; // Margem para espaçamento
`;

export const FooterContainer = styled.footer`
  background-color: #333; /* Cor de fundo do rodapé */
  color: white; /* Cor do texto */
  padding: 20px 0; /* Espaçamento ao redor do conteúdo */
  text-align: center; /* Centraliza o conteúdo no rodapé */
  position: relative;
  bottom: 0;
  width: 100%;
`;

export const FooterText = styled.p`
  font-size: 14px; /* Tamanho da fonte do texto */
  margin: 0; /* Remove margens extras */
`;

export const FooterLink = styled.a`
  color: #E6E6FA; /* Cor dos links */
  text-decoration: none; /* Remove o sublinhado */
  margin: 0 10px; /* Espaçamento entre os links */
  
  &:hover {
    text-decoration: underline; /* Adiciona sublinhado ao passar o mouse */
  }
`;

export const FooterIcons = styled.div`
  margin-top: 10px; /* Espaçamento acima dos ícones */
  
  a {
    color: white;
    margin: 0 10px;
    font-size: 20px;
    display: inline-block;
    
    &:hover {
      color: #E6E6FA; /* Muda a cor ao passar o mouse */
    }
  }
`;


export const Logo = styled.div`
  width: 100%; /* Ocupa toda a largura da tela */
  padding: 20px 0; /* Espaçamento ao redor da imagem */
  display: flex;
  justify-content: left; /* Centraliza a imagem horizontalmente */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Adiciona uma sombra sutil */
  
  top: 0; /* Posiciona o logo no topo da página */
  z-index: 1000; /* Garante que o logo fique acima de outros elementos */
  img {
    width: 70px; /* Ajuste o tamanho da imagem */
    height: auto;
    border-radius:150px;
  }
`;

export const Menu = styled.nav`
  display: flex;
  justify-content: center;
  background-color:black;
  height: 100px;
  align-items: center; /* Alinha os itens no centro verticalmente */
  flex-direction: row; /* Garante que os itens estejam alinhados horizontalmente */
  width: 100%; /* Garante que o menu ocupe toda a largura disponível */
  position: fixed; /* Fixa o menu logo abaixo do logo */
  top: 0px; /* Posiciona o menu logo abaixo do logo */
  z-index: 999; /* Garante que o menu fique abaixo do logo, mas acima de outros elementos */
`;

export const InicialConteiner = styled.div`
  margin-top: 20px;
  padding: 20px;
  display: flex;
  justify-content: center; /* Centraliza o conteúdo horizontalmente */
  align-items: center; /* Centraliza o conteúdo verticalmente */
  width: 100%;
`;

export const CarouselContainer = styled.div`
  width: 80%;
  margin: 20px auto;
  padding: 20px 0;
`;

export const MenuItem = styled.div`
  margin: 0 15px;
  a {
    color: white;
    text-decoration: none;
    font-size: 25px;
  }
  a:hover {
    text-decoration: underline;
  }
`;

// Wrapper for the dropdown menu
export const Dropdown = styled.div`
  position: relative; /* Ensures the dropdown content is positioned relative to this container */
  display: inline-block; /* Makes sure the dropdown is inline with other menu items */
`;

// Dropdown content styles
export const DropdownContent = styled.div`
  display: none; /* Initially hidden */
  position: absolute; /* Positioned relative to the Dropdown wrapper */
  background-color: #333; /* Background color of the dropdown */
  min-width: 160px; /* Minimum width of the dropdown */
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); /* Shadow effect for dropdown */
  z-index: 1; /* Ensures dropdown is above other elements */
  
  /* Styles for dropdown items */
  a {
    color: white; /* Text color of dropdown items */
    padding: 12px 16px; /* Padding around text */
    text-decoration: none; /* No underline on links */
    display: block; /* Makes each item a block element */
  }

  a:hover {
    background-color: #575757; /* Background color on hover */
  }
`;

// Show the dropdown content on hover
export const DropdownTrigger = styled.div`
  &:hover ${DropdownContent} {
    display: block; /* Show dropdown content when hovering over the trigger */
  }
`;
