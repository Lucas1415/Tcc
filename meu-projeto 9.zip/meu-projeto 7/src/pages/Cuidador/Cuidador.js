import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import * as C from "./style"; 
import Logo_top from '../Home/Logo_top.jpeg';
import Respirando from './img/Respirando.jpg';
import Atv from './img/AtvFisica.jpg';
import Sorrindo from './img/Sorrindo.jpg';
import AlzheimerAvancado from './img/AlzheimerAvancado.jpg';

const Cuidador = () => {
  const [stages, setStages] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:8080/api/alzheimer") // Ajuste o endpoint conforme necessário
      .then((response) => response.json())
      .then((data) => setStages(data))
      .catch((error) => console.error("Erro ao buscar estágios:", error));
  }, []);

  const handleSignout = () => {
    navigate('/');
  };

  return (
    <C.MenuContainer>
      <C.Menu>
        <C.MenuItem>
          <C.Logo>
            <img src={Logo_top} alt="Logo" /> 
          </C.Logo>
        </C.MenuItem>
        <C.MenuItem>
          <Link to="/home">Home</Link>
        </C.MenuItem>
        <C.MenuItem>
          <Link to="/Cuidador">Cuidador</Link>

        </C.MenuItem>
      </C.Menu>

      <C.InicialConteiner>
        <C.Header>
          <C.Title>Essa página foi feita para cuidar de você, cuidador!</C.Title>
          <C.Text>Sabemos que a sua saúde também é importante...</C.Text>
          <C.Text>Então vamos te dar dicas para se manter firme!</C.Text>

        </C.Header>

        {stages.map((stage, index) => (
          <C.Section key={stage.id} style={{ backgroundColor: stage.color }}>
            <C.SectionImage>
              <img
                src={
                  index === 0 ? Respirando :
                  index === 1 ? Atv :
                  index === 2 ? Sorrindo :
                  index === 3 ? AlzheimerAvancado :
                  AlzheimerAvancado
                }
                alt={stage.name}
              />
            </C.SectionImage>
            <C.SectionContent>
              <C.SubTitle>{stage.name}</C.SubTitle>
              <C.Text>{stage.description}</C.Text>
              <C.CareTakerTip>
                <strong>Respirando:</strong> {stage.caretakerTip}
              </C.CareTakerTip>
            </C.SectionContent>
          </C.Section>
        ))}
      </C.InicialConteiner>
    </C.MenuContainer>
  );
};

export default Cuidador;
