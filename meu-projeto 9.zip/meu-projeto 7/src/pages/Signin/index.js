import React, { useState } from "react";
import Button from "../../components/Button"; // Certifique-se de que o componente Button está funcionando corretamente
import * as C from "./style";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    senha: '',
  });
  const [error, setError] = useState(""); // Para exibir mensagens de erro
  const navigate = useNavigate(); // Hook para navegação

  // Função para atualizar os campos do formulário
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setLoginData({
      ...loginData,
      [name]: value,  // Atualiza o valor correspondente no estado
    });
  };

  // Função para lidar com o login
  const handleLogin = async (e) => {
    e.preventDefault();  // Previne o envio do formulário e o comportamento padrão do navegador
  
    try {
      
      const response = await fetch('http://localhost:8080/api/login', {  
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: loginData.email,
          senha: loginData.senha
        })
      });
  
      // Obter a resposta como texto
      const textResponse = await response.text();  // Usando text() para obter a resposta como texto simples
      console.log("Resposta do login:", textResponse);
  
      if (response.ok) {
        // Caso o login seja bem-sucedido, armazene o token ou as informações do usuário
        localStorage.setItem('user', JSON.stringify(textResponse));  // Exemplo de armazenamento local
        navigate('/home');
      } else {
        // Caso o login não seja bem-sucedido, exiba a mensagem de erro
        setError(textResponse);  // Exibe o erro que foi retornado do backend
      }
    } catch (err) {
      console.error("Erro no login:", err);
      setError("Erro no servidor. Tente novamente mais tarde.");
    }
  };
  
  return (
    <C.Container>
      <C.Label>LOGIN</C.Label>
      <form onSubmit={handleLogin}> {/* Usando onSubmit para o envio de dados */}
        <C.Container>
          <C.Input
            type="email"
            name="email"
            placeholder="Digite seu E-mail"
            value={loginData.email}
            onChange={handleInputChange}
          />
          
          <C.Input
            type="password"
            name="senha"
            placeholder="Digite sua Senha"
            value={loginData.senha}
            onChange={handleInputChange}
          />
          
          {error && <C.LabelError>{error}</C.LabelError>} {/* Exibe erro se houver */}
          
          <Button Text="Login" onClick={handleLogin} />

          <C.LabelSignin>
            Não tem uma conta?
            <C.Strong>
              <Link to="/signup">&nbsp;Cadastre-se</Link> {/* Redireciona para a tela de cadastro */}
            </C.Strong>
          </C.LabelSignin>
        </C.Container>
      </form>
    </C.Container>
  );
};

export default Login;