package com.tcc.API.Models;

import jakarta.persistence.*;

import java.util.Objects;


@Entity
@Table
public class Paciente {
    //ID,Nome, Idade, localização
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer id;
    @Column(length = 50, nullable = false)

    private String name;
    @Column(length = 100)

    private Integer Idade;
    @Column(length = 50, nullable = false)

    private Double localizacao;

    public Paciente(Integer id, String name, Integer idade, Double localizacao) {
        this.id = id;
        this.name = name;
        this.Idade = idade;
        this.localizacao = localizacao;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getIdade() {
        return Idade;
    }

    public void setIdade(Integer idade) {
        Idade = idade;
    }

    public Double getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(Double localizacao) {
        this.localizacao = localizacao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Paciente paciente = (Paciente) o;
        return Objects.equals(id, paciente.id) && Objects.equals(name, paciente.name) && Objects.equals(Idade, paciente.Idade) && Objects.equals(localizacao, paciente.localizacao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, Idade, localizacao);
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
