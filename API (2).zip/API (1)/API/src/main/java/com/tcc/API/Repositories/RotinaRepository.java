package com.tcc.API.Repositories;

import com.tcc.API.Models.Rotina;
import org.springframework.data.jpa.repository.JpaRepository;



public interface RotinaRepository extends JpaRepository<Rotina, Integer> {
}
