package com.tcc.API.Models;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table
public class Cuidador {
    //id, nome, idade, localizaçao
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer CuidadorId;
    @Column(length = 50, nullable = false)

    private String name;
    @Column(length = 100)

    private Integer idade;
    @Column

    private Double localizacao;


    public Cuidador(Integer cuidadorId, String name, Integer idade, Double localizacao) {
        this.CuidadorId = cuidadorId;
        this.name = name;
        this.idade = idade;
        this.localizacao = localizacao;
    }

    public Integer getCuidadorId() {
        return CuidadorId;
    }

    public void setCuidadorId(Integer cuidadorId) {
        CuidadorId = cuidadorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public Double getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(Double localizacao) {
        this.localizacao = localizacao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cuidador cuidador = (Cuidador) o;
        return Objects.equals(CuidadorId, cuidador.CuidadorId) && Objects.equals(name, cuidador.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(CuidadorId, name);
    }

    @Override
    public String toString() {
        return "Cuidador{" +
                "CuidadorId=" + CuidadorId +
                ", name='" + name + '\'' +
                '}';
    }
}
