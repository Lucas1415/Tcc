package com.tcc.API.Repositories;

import com.tcc.API.Models.Cuidador;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CuidadorRepository extends JpaRepository<Cuidador, Integer> {
    //os metodos do crud ja estao implementados
}
