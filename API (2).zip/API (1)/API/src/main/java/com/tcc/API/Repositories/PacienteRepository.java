package com.tcc.API.Repositories;

import com.tcc.API.Models.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PacienteRepository extends JpaRepository<Paciente, Integer> {
}
