package com.Teste.Teste.Controller;
import com.Teste.Teste.Models.Texto;
import com.Teste.Teste.Repository.TextoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/texto")
public class TextoController {

    @Autowired
    private TextoRepository textoRepository;

        // Método GET para pegar todos os textos
        @GetMapping("/textos")
        public List<Texto> getTextos() {
            return textoRepository.findAll();
        }


        @PostMapping("/insert")
        public Texto addTexto(@RequestBody Texto novoTexto) {
            return textoRepository.save(novoTexto);
        }
    }

