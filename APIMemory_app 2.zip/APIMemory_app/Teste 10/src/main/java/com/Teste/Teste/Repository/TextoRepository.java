package com.Teste.Teste.Repository;

import com.Teste.Teste.Models.Texto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TextoRepository extends JpaRepository<Texto, Integer> {
}
