package com.Teste.Teste.Controller;

import com.Teste.Teste.Models.Usuario;
import com.Teste.Teste.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth") // Define o recurso da API
public class AuthController {

    @Autowired
    private UsuarioRepository repository;

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody Usuario newUsuario) {
        // Validação de dados (por exemplo, verificar se o e-mail já existe)
        if (UsuarioRepository.findByEmail(newUsuario.getEmail()) != null) {
            return ResponseEntity.badRequest().body("E-mail já está em uso");
        }

        // Salva o novo usuário
        repository.save(newUsuario);
        return ResponseEntity.status(201).body("Usuário cadastrado com sucesso!"); // 201 Created
    }

    // Método para login
    @PostMapping("/signin")
    public ResponseEntity<String> signin(@org.jetbrains.annotations.NotNull @RequestBody Usuario loginData) {
        String email = loginData.getEmail();
        String senha = loginData.getSenha();

        Usuario usuario = UsuarioRepository.findByEmail(email);
        if (usuario != null && usuario.getSenha().equals(senha)) {
            // Aqui você pode gerar um token (JWT, por exemplo) e retorná-lo
            return ResponseEntity.ok("Login bem-sucedido!"); // Retornar o token se implementar
        } else {
            return ResponseEntity.status(401).body("E-mail ou senha incorretos"); // 401 Unauthorized
        }
    }
}
