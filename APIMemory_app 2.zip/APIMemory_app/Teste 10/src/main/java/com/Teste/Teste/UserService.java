package com.Teste.Teste;

import com.Teste.Teste.Models.Usuario; // Ensure this import points to your User model
// Make sure to import your repository
import com.Teste.Teste.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UsuarioRepository userRepository; // Use UserRepository for database access

    public Usuario findByEmail(String email) {
        return UsuarioRepository.findByEmail(email); // Call the repository method
    }
}
