import React, { useState } from "react";
import Input from "../../components/Input";
import Button from "../../components/Button";
import * as C from "./style";
import { Link, useNavigate } from "react-router-dom";

const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    emailConf: '',
    senha: '',
  });
  const [error, setError] = useState(""); // Para exibir mensagens de erro
  const navigate = useNavigate();

  // Função para atualizar os campos do formulário
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Função para lidar com o cadastro
  const handleSignup = async (e) => {
    e.preventDefault();

    // Verifica se os e-mails coincidem
    if (formData.email !== formData.emailConf) {
      setError("Os e-mails não coincidem!");
      return;
    }

    try {
      const response = await fetch("http://localhost:8080/api/registrar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          senha: formData.senha,
        }),
      }); 

      if (response.ok) {
        const data = await response.json();
        console.log("Usuário cadastrado com sucesso:", data);
        navigate("/"); // Redireciona para a página inicial
      } else {
        setError("Erro ao cadastrar. Verifique os dados.");
      }
    } catch (err) {
      console.error("Erro no cadastro:", err);
      setError("Erro no servidor. Tente novamente mais tarde.");
    }
  };

  return (
    <C.Container>
      <C.Label>SISTEMA DE CADASTRO</C.Label>
      <C.Container onSubmit={handleSignup}> {/* Aqui você deve usar onSubmit para o formulário */}
        <Input 
          type="text" // Corrija o tipo para "text" para o nome
          placeholder="Digite seu Nome"
          name="name"
          value={formData.name}
          onChange={handleChange} // Chame handleChange diretamente
        />
        <Input
          type="email"
          placeholder="Digite seu E-mail"
          name="email"
          value={formData.email}
          onChange={handleChange} // Chame handleChange diretamente
        />
        <Input
          type="email" // Adicione um campo para confirmação de e-mail
          placeholder="Confirme seu E-mail"
          name="emailConf"
          value={formData.emailConf}
          onChange={handleChange} // Chame handleChange diretamente
        />
        <Input
          type="password"
          placeholder="Digite sua Senha"
          name="senha"
          value={formData.senha}
          onChange={handleChange} // Chame handleChange diretamente
        />
        {error && <C.LabelError>{error}</C.LabelError>} {/* Exibe erros */}
        <Button Text="Cadastre-se" type="submit" /> {/* Adicione type="submit" */}
        <C.LabelSignin>
          Já tem uma conta?
          <C.Strong>
            <Link to="/">&nbsp;Entre</Link>
          </C.Strong>
        </C.LabelSignin>
      </C.Container>
    </C.Container>
  );
};

export default Signup;