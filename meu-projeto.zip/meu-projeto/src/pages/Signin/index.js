import React, { useState } from "react";
import Input from "../../components/Input";  // Certifique-se de que o componente Input está funcionando corretamente
import Button from "../../components/Button";
import * as C from "./style";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    senha: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setLoginData({
      ...loginData,
      [name]: value,  // Atualiza o valor correspondente no estado
    });
  };

  const handleLogin = async (e) => {
    e.preventDefault();  // Previne o envio do formulário

    try {
      const response = await fetch('http://localhost:8080/api/login', {
        method: 'POST',
        body: JSON.stringify(loginData),
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const json = await response.json();
      console.log(response.status);
      console.log(json);
      
      // Navega ou faz algo após o login
    } catch (err) {
      console.error("Erro ao fazer login:", err);
    }
  };

  return (
    <C.Container>
      <C.Label>LOGIN</C.Label>
      <form onSubmit={handleLogin}> {/* Usando form para o envio de dados */}
        <C.Container>
          <Input
            type="email"
            name="email"
            placeholder="Digite seu E-mail"
            value={loginData.email}
            onChange={handleInputChange}
          />
          
          <Input
            type="password"
            name="senha"
            placeholder="Digite sua Senha"
            value={loginData.senha}
            onChange={handleInputChange}
          />
          
          <Button Text="Entrar" />
          
          <C.LabelSignin>
            Não tem uma conta?
            <C.Strong>
              <Link to="/signup">&nbsp;Cadastre-se</Link>
            </C.Strong>
          </C.LabelSignin>
        </C.Container>
      </form>
    </C.Container>
  );
};

export default Login;
