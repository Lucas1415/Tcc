import React, { createContext, useState, useEffect } from 'react';
import api from '../Api/Api';  // Seu arquivo de configuração de API

export const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  // Verifica se o usuário está autenticado com base no token
  useEffect(() => {
    api.get("/usuarios")
      .then((response) => {
        setUsuarios(response.data); // Atualiza o estado com a lista de usuários
      })
      .catch((error) => {
        console.error("Erro ao buscar usuários:", error);
      });
  }, []); // O efeito só será executado uma vez, após o primeiro render

  return (
    <AuthContext.Provider value={{ user }}>
      {children}
    </AuthContext.Provider>
  );
};
