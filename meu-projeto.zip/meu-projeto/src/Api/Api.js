import axios from "axios";

const api = axios.create({
  baseURL: "https://localhost:8080/api",  // Coloque o baseURL da sua API aqui
});

export default api;
