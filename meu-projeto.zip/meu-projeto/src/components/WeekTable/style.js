import styled from 'styled-components';

export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
`;

export const TableHeader = styled.th`
  background-color: black;
  padding: 10px;
  border: 1px solid white;
  text-align: center;
  color:white
`;

export const TableCell = styled.td`
  padding: 10px;
  border: 1px solid white;
  text-align: center;
  font-size: 16px;
  font-weight: bold;
`;
