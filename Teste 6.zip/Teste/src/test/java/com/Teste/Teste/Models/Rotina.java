package com.Teste.Teste.Models;



import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table
public class Rotina {
    //id, dias da semana
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer id;
    @Column(length = 50, nullable = false)

    private String SegundaFeira;
    @Column(length = 100)

    private String TercaFeira;
    @Column(length = 100)

    private String QuartaFeira;
    @Column(length = 100)

    private String QuintaFeira;
    @Column(length = 100)

    private String SextaFeira;
    @Column(length = 100)

    private String Sabado;
    @Column(length = 100)

    private String Domingo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSegundaFeira() {
        return SegundaFeira;
    }

    public void setSegundaFeira(String segundaFeira) {
        SegundaFeira = segundaFeira;
    }

    public String getTercaFeira() {
        return TercaFeira;
    }

    public void setTercaFeira(String tercaFeira) {
        TercaFeira = tercaFeira;
    }

    public String getQuartaFeira() {
        return QuartaFeira;
    }

    public void setQuartaFeira(String quartaFeira) {
        QuartaFeira = quartaFeira;
    }

    public String getQuintaFeira() {
        return QuintaFeira;
    }

    public void setQuintaFeira(String quintaFeira) {
        QuintaFeira = quintaFeira;
    }

    public String getSextaFeira() {
        return SextaFeira;
    }

    public void setSextaFeira(String sextaFeira) {
        SextaFeira = sextaFeira;}

    public String getSabado() {
        return Sabado;
    }

    public void setSabado(String sabado) {
        Sabado = sabado;
    }

    public String getDomingo() {
        return Domingo;
    }

    public void setDomingo(String domingo) {
        Domingo = domingo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rotina rotina = (Rotina) o;
        return Objects.equals(id, rotina.id) && Objects.equals(SegundaFeira, rotina.SegundaFeira) && Objects.equals(TercaFeira, rotina.TercaFeira) && Objects.equals(QuartaFeira, rotina.QuartaFeira) && Objects.equals(QuintaFeira, rotina.QuintaFeira) && Objects.equals(SextaFeira, rotina.SextaFeira) && Objects.equals(Sabado, rotina.Sabado) && Objects.equals(Domingo, rotina.Domingo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, SegundaFeira, TercaFeira, QuartaFeira, QuintaFeira, SextaFeira, Sabado, Domingo);
    }

    @Override
    public String toString() {
        return "Rotina{" +
                "id=" + id +
                ", SegundaFeira='" + SegundaFeira + '\'' +
                ", TercaFeira='" + TercaFeira + '\'' +
                ", QuartaFeira='" + QuartaFeira + '\'' +
                ", QuintaFeira='" + QuintaFeira + '\'' +
                ", SextaFeira='" + SextaFeira + '\'' +
                ", Sabado='" + Sabado + '\'' +
                ", Domingo='" + Domingo + '\'' +
                '}';
    }
}
