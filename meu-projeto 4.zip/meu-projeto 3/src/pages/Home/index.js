import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import * as C from './style';
import './stilo.css';
import { motion } from 'framer-motion';
import Logo_top from '../Home/Logo_top.jpeg';
import useAuth from '../../hooks/useAuth';
import Button from '../../components/Button';
import ImageClube from './ImageClube.jpg';
import image1 from '../../images/img1.jpg';
import image2 from '../../images/img2.jpg';
import image3 from '../../images/img3.jpg';
import image4 from '../../images/img4.jpg';

const Home = () => {
    const { signout, user } = useAuth();
    const navigate = useNavigate();
    const [textos, setTextos] = useState([]);
    const images = [image1, image2, image3, image4];

    const handleSignout = () => {
        signout();
        navigate('/');
    };

    useEffect(() => {
        const fetchTextos = async () => {
            try {
                const response = await fetch("http://localhost:8080/texto/textos");
                const data = await response.json();
                setTextos(data); // Armazena os textos recebidos da API
            } catch (error) {
                console.error("Erro ao buscar textos:", error);
            }
        };

        fetchTextos(); // Carrega os textos ao inicializar o componente
    }, []);

    // Função para pegar o texto baseado no tipo
    const getTextByType = (tipo) => {
        // Verifica se há algum objeto no array de textos
        if (textos.length > 0) {
            // Pegando o primeiro objeto (você pode adaptar isso caso tenha mais de um item)
            const texto = textos[0];  // Aqui estamos assumindo que a resposta tem apenas um item
            return texto[tipo] || ''; // Retorna o conteúdo ou uma string vazia se não encontrar
        }
        return ''; // Caso não tenha textos carregados
    };

    return (
        <C.MenuContainer>
            <C.Menu>
                <C.MenuItem>
                    <C.Logo>
                        <img src={Logo_top} alt="Logo" />
                    </C.Logo>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/home">Home</Link>
                </C.MenuItem>
                <C.MenuItem>
                    <C.DropdownTrigger>
                        <Link>Semana</Link>
                        <C.DropdownContent>
                            <Link to="/Segunda">Segunda</Link>
                            <Link to="/Terca">Terça</Link>
                            <Link to="/Quarta">Quarta</Link>
                            <Link to="/Quinta">Quinta</Link>
                            <Link to="/Sexta">Sexta</Link>
                            <Link to="/Sabado">Sábado</Link>
                            <Link to="/Domingo">Domingo</Link>
                        </C.DropdownContent>
                    </C.DropdownTrigger>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/Cuidador">Cuidador</Link>
                </C.MenuItem>
                <C.MenuItem>
                {!user ? (
                        <Button Text="Login" onClick={() => navigate('/Signin')} />
                    ) : (
                        <Button Text="Sair" onClick={handleSignout} />
                    )}
                </C.MenuItem>
            </C.Menu>

            <C.Container>
                <h1>{getTextByType("titulo")}</h1> {/* Exibe o título */}
                <C.Title>{getTextByType('titulo2')}</C.Title>  {/* Exibe o segundo título */}
                <C.Subtitle>{getTextByType('subtitulo')}</C.Subtitle>  {/* Exibe o subtítulo */}
                <C.CaixaText>
                    <C.TableText>
                        <C.Texto>{getTextByType('descricao')}</C.Texto> {/* Descrição principal */}
                    </C.TableText>
                    <C.TableText2>
                        <C.Titulo>{getTextByType('titulo2')}</C.Titulo>
                        <C.Texto>{getTextByType('descricao2')}</C.Texto> {/* Segunda descrição */}
                        <C.MicroText>{getTextByType('microtexto')}</C.MicroText> {/* Microtexto */}
                    </C.TableText2>
                </C.CaixaText>
            </C.Container>

            <C.aboutSection>
                <C.aboutText>
                    <C.SubTitle>{getTextByType('quemSomosTitulo')}</C.SubTitle>
                    <C.Text>{getTextByType('quemSomosDescricao')}</C.Text>
                </C.aboutText>
                <C.aboutImage>
                    <img src={ImageClube} alt="Clube" />
                </C.aboutImage>
            </C.aboutSection>

            <C.FooterContainer>
                <C.FooterText>{getTextByType('rodape')}</C.FooterText> {/* Rodapé */}
                <C.FooterIcons>
                    <C.FooterLink href="#">Facebook</C.FooterLink>
                    <C.FooterLink href="#">Instagram</C.FooterLink>
                    <C.FooterLink href="#">Twitter</C.FooterLink>
                </C.FooterIcons>
            </C.FooterContainer>
        </C.MenuContainer>
    );
};

export default Home;
