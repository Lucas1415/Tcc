// src/components/MenuLayout.js
import React from 'react';
import { Link } from 'react-router-dom';
import * as C from './Style';
import Logo_top from '../../pages/Home/Logo_top.jpeg'
import Button from '../Button';

    const MenuLayout = ({ children }) => {
        // Definindo a função handleSignout
        const handleSignout = () => {
            console.log("Usuário deslogado.");
            // Aqui você pode adicionar a lógica para realizar o logout, como limpar tokens, redirecionar, etc.
        };
    
        return (
    
    <C.MenuContainer>
    <script src="//code.tidio.co/7d5krcbcz0g5bfz4ebh0irgo2rnirhnt.js"></script>
    <C.Logo>
    <img src={Logo_top} alt="Logo" /> 
    </C.Logo>
<C.Menu>
<C.MenuItem>
    <Link to="/home">Home</Link>
</C.MenuItem>
<C.MenuItem>
    <Link to="/semana">Semana</Link>
</C.MenuItem>
<C.MenuItem>
    <Link to=" ">Cuidador</Link>
</C.MenuItem>
</C.Menu>
<C.InicialConteiner>
   
   
</C.InicialConteiner>
<Button Text="Sair" onClick={handleSignout} />
</C.MenuContainer>
);
    }
export default MenuLayout;
