import menu from "./logo-menu.png";
function Login(){
    return(
        <div className="App">
        <div class="Menu-top">
          <h1>Memory</h1>
       <nav>
          <ul class="menu">
              <li><img src={menu} alt="menu"/></li>
              <li><a href="#home">Home</a></li>
              <li><a href="#sobre">Sobre</a></li>
              <li><a href="#servicos">Serviços</a></li>
              <li><a href="#contato">Contato</a></li>
          </ul>
       </nav>
         </div>
      </div>
    )

}

export default Login