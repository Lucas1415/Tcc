import React from 'react';
// src/index.js ou src/App.js
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import './App.css';
import GlobalStyle from './global';
import RouterApp from './routes';
import { AuthProvider } from './contexts/auth';

const App = () => {
  return (
    <AuthProvider>
      <RouterApp />
      <GlobalStyle />
    </AuthProvider>
  );
}

export default App;
