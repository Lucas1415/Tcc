import React, { createContext, useEffect, useState } from 'react';

export const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const userToken = localStorage.getItem("user_token");
        const usersStorage = localStorage.getItem("users_db");

        if (userToken && usersStorage) {
            const tokenData = JSON.parse(userToken);
            const users = JSON.parse(usersStorage);
            const hasUser = users.find(user => user.email === tokenData.email);
            if (hasUser) setUser(hasUser);
        }
    }, []);

    const signin = (email, password) => {
        try {
            const usersStorage = JSON.parse(localStorage.getItem("users_db"));
            const hasUser = usersStorage?.find(user => user.email === email);

            if (hasUser) {
                if (hasUser.password === password) {
                    const token = Math.random().toString(36).substring(2); // Tokens são gerados de forma insegura
                    localStorage.setItem("user_token", JSON.stringify({ email, token }));
                    setUser(hasUser);
                    return;
                } else {
                    return "E-mail ou senha incorretos";
                }
            } else {
                return "Usuário não cadastrado";
            }
        } catch (error) {
            console.error("Erro ao tentar fazer login:", error);
            return "Erro ao tentar fazer login";
        }
    };

    const signup = (email, password) => {
        try {
            const usersStorage = JSON.parse(localStorage.getItem("users_db")) || [];

            if (usersStorage.some(user => user.email === email)) {
                return "Já tem uma conta com esse E-mail";
            }

            const newUser = [...usersStorage, { email, password }];
            localStorage.setItem("users_db", JSON.stringify(newUser));
        } catch (error) {
            console.error("Erro ao tentar se cadastrar:", error);
            return "Erro ao tentar se cadastrar";
        }
    };

    const signout = () => {
        setUser(null);
        localStorage.removeItem("user_token");
    };

    return (
        <AuthContext.Provider
            value={{ user, signed: !!user, signin, signup, signout }}
        >
            {children}
        </AuthContext.Provider>
    );
};
