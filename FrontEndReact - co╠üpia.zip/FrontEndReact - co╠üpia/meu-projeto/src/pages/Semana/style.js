import styled from 'styled-components';


export const MenuContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  background: linear-gradient(to bottom, #E6E6FA, #800080); /* Degradê do lilás ao roxo */
  min-height: 100vh; /* Garante que o fundo cubra toda a altura da tela */
  padding-top: 200px; /* Adiciona espaçamento no topo para acomodar o logo e o menu */
`;

export const Logo = styled.div`
  width: 100%; /* Ocupa toda a largura da tela */
  padding: 20px 0; /* Espaçamento ao redor da imagem */
  display: flex;
  justify-content: left; /* Centraliza a imagem horizontalmente */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Adiciona uma sombra sutil */
  
  top: 0; /* Posiciona o logo no topo da página */
  z-index: 1000; /* Garante que o logo fique acima de outros elementos */
  img {
    width: 70px; /* Ajuste o tamanho da imagem */
    height: auto;
    border-radius:150px;
  }
`;

export const Menu = styled.nav`
  display: flex;
  justify-content: center;
  background-color:black;
  height: 100px;
  align-items: center; /* Alinha os itens no centro verticalmente */
  flex-direction: row; /* Garante que os itens estejam alinhados horizontalmente */
  width: 100%; /* Garante que o menu ocupe toda a largura disponível */
  position: fixed; /* Fixa o menu logo abaixo do logo */
  top: 0px; /* Posiciona o menu logo abaixo do logo */
  z-index: 999; /* Garante que o menu fique abaixo do logo, mas acima de outros elementos */
`;

export const WeekTable = styled.div`
  height: 500px;
  width: 100%; /* Ocupa a largura total disponível */
  display: flex;
  justify-content: center; /* Centraliza o conteúdo horizontalmente */
  align-items: center; /* Centraliza o conteúdo verticalmente */
`;

export const MenuItem = styled.div`
  margin: 0 15px;
  a {
    color: white;
    text-decoration: none;
    font-size: 25px;
  }
  a:hover {
    text-decoration: underline;
  }
`;

export const InicialConteiner = styled.div`
  margin-top: 20px;
  padding: 20px;
  display: flex;
  justify-content: center; /* Centraliza o conteúdo horizontalmente */
  align-items: center; /* Centraliza o conteúdo verticalmente */
  width: 100%;
`;


// Wrapper for the dropdown menu
export const Dropdown = styled.div`
  position: relative; /* Ensures the dropdown content is positioned relative to this container */
  display: inline-block; /* Makes sure the dropdown is inline with other menu items */
`;

// Dropdown content styles
export const DropdownContent = styled.div`
  display: none; /* Initially hidden */
  position: absolute; /* Positioned relative to the Dropdown wrapper */
  background-color: #333; /* Background color of the dropdown */
  min-width: 160px; /* Minimum width of the dropdown */
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); /* Shadow effect for dropdown */
  z-index: 1; /* Ensures dropdown is above other elements */
  
  /* Styles for dropdown items */
  a {
    color: white; /* Text color of dropdown items */
    padding: 12px 16px; /* Padding around text */
    text-decoration: none; /* No underline on links */
    display: block; /* Makes each item a block element */
  }

  a:hover {
    background-color: #575757; /* Background color on hover */
  }
`;

// Show the dropdown content on hover
export const DropdownTrigger = styled.div`
  &:hover ${DropdownContent} {
    display: block; /* Show dropdown content when hovering over the trigger */
  }
`;
