import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Button from '../../components/Button';
import useAuth from '../../hooks/useAuth';
import * as C from "./style"; 
import WeekTable from '../../components/WeekTable/WeekTable';
import Logo_top from '../Home/Logo_top.jpeg';
import AlzheimerInicial from './azheimerInicial.jpg';
import alzheimerMedio from './alzheimerMedio.jpg';
import AlzheimerAvancado from './AlzheimerAvancado.jpg';

const Cuidador = () => {
  const { signout } = useAuth();
  const navigate = useNavigate();

  const handleSignout = () => {
    signout();
    navigate('/');
  };

  return (
    <C.MenuContainer>
    <script src="//code.tidio.co/7d5krcbcz0g5bfz4ebh0irgo2rnirhnt.js"></script>
  
<C.Menu>
<C.MenuItem>
    <C.Logo>
<img src={Logo_top} alt="Logo" /> 
</C.Logo>
</C.MenuItem>
<C.MenuItem>
    <Link to="/home">Home</Link>
</C.MenuItem>
<C.MenuItem>
<C.DropdownTrigger>
<C.MenuItem>
<Link >Semana</Link>
</C.MenuItem>
<C.DropdownContent>
<Link to="/Segunda">Segunda</Link>
        <Link to="/Terca"> Terça</Link>
        <Link to="/Quarta">Quarta</Link>
        <Link to="/Quinta">Quinta</Link>
        <Link to="/Sexta">Sexta</Link>
        <Link to="/Sabado">Sabado</Link>
        <Link to="/Domingo">Domingo</Link>

</C.DropdownContent>
</C.DropdownTrigger>

</C.MenuItem>
<C.MenuItem>
    <Link to="Cuidador">Cuidador</Link>
</C.MenuItem>
</C.Menu>
<C.InicialConteiner>
    <C.Header>
   <C.Title>Estágios do Alzheimer</C.Title>
   <C.Text> A doença tem três estágios principais: inicial, moderado e avançado.Conheça os sintomas e saiba o papel dos familiares e/ou cuidadores em cada fase</C.Text> 
   </C.Header>
   <C.Section style={{backgroundColor: '#cceff8'}}>
    <C.SectionImage>
    <img src={AlzheimerInicial} alt="Incial" /> 
    </C.SectionImage>
    <C.SectionContent>
        <C.SubTitle>Inicial</C.SubTitle>
        <C.Text>O paciente pode ter lapsos de memória, como esquecer a localização de objetos, mas ainda é independente.Há mudanças na 
            personalidade e no humor e prejuízo das habilidades visuais e espaciais, oque pode provocar mais quedas.
        </C.Text>
        <C.CareTakerTip>
            <strong>Funções do Cuidador:</strong> O cuidador deve lidar com a aceitação da doença, decidir sobre  a revelação ou não do diagnóstico para O
            paciente e se informar a respeito da doença e seus tratamentos.
        </C.CareTakerTip>

    </C.SectionContent>

   </C.Section>

   <C.Section style={{ backgroundColor: '#ffe7d4'}}>
<C.SectionImage>
<img src={alzheimerMedio} alt="Medio" /> 
</C.SectionImage>
<C.SectionContent>
    <C.SubTitle>Moderado</C.SubTitle>
    <C.Text>Principais sintomas: dificuldade na fala e problemas na coordenação motora. Pode haver agitação, insônia, 
        comportamento repetitivo e esquecimento de  fatos importantes da vida e de informações  pessoais. Essa fase é mais 
        longa e pode durar anos.
        </C.Text>
        <C.CareTakerTip>
            <strong> Funções do Cuidador:</strong> O cuidador precisa garantir a segurnaça física, emocional
            e financeira do paciente, considerar contratar um cuidador em tempo integral e estabelecer novas
            formas de relacionamento.
        </C.CareTakerTip>
</C.SectionContent>
   </C.Section>
   <C.Section style={{ backgroundColor: '#d4e1ff'}}>
    <C.SectionImage>
    <img src={AlzheimerAvancado} alt="Avancado" /> 
    </C.SectionImage>
    <C.SectionContent>
        <C.SubTitle>Avançado</C.SubTitle>
        <C.Text>O paciente resiste à execução de tarefas simples, tem dificuldade para comer e se comunicar, defieciência
            motora progressiva e incontinência urinária e fecal. perda de consciência de experiência recentes e maior
            risco de contrair infecções.
        </C.Text>
        <C.CareTakerTip>
            <strong>Funções do Cuidador:</strong> O cuidador deve manter os cuidados da fase moderada, mas de formas
            intensiva. Falar pausadamente, fazer perguntas simples e estimular o paciente  responder  com gestos.
        </C.CareTakerTip>
    </C.SectionContent>
   </C.Section>
</C.InicialConteiner>

</C.MenuContainer>  
);
};

export default Cuidador;
