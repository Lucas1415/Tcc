import React, { useEffect, useState } from 'react';
import Card from './Card';
import { Container } from './style';  // Importação correta

const CardContainer = () => {
  const [rotinas, setRotinas] = useState([]);  // Estado para armazenar os dados da API

  useEffect(() => {
    // Função para buscar as rotinas da API
    const fetchRotinas = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/rotina");  // Altere a URL conforme o seu servidor
        const data = await response.json();
        setRotinas(data);  // Armazena os dados retornados no estado
      } catch (error) {
        console.error("Erro ao buscar rotinas:", error);
      }
    };

    fetchRotinas();  // Chama a função ao carregar o componente
  }, []);  // O array vazio faz com que o efeito seja executado uma vez ao carregar o componente

  return (
    <Container>
      {rotinas.map(rotina => (
        <Card
          key={rotina.id}
          imageSrc={rotina.imageSrc || '../images/default.jpg'}  // Verifica se a imagem existe
          title={rotina.title}  // Puxa o título da rotina
          description={rotina.description}  // Puxa a descrição da rotina
        />
      ))}
    </Container>
  );
};

export default CardContainer;
