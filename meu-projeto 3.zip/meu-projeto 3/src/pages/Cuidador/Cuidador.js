import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import * as C from "./style"; 
import Logo_top from '../Home/Logo_top.jpeg';
import AlzheimerInicial from './azheimerInicial.jpg';
import alzheimerMedio from './alzheimerMedio.jpg';
import AlzheimerAvancado from './AlzheimerAvancado.jpg';

const Cuidador = () => {
  const [stages, setStages] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:8080/api/stages") // Ajuste o endpoint conforme necessário
      .then((response) => response.json())
      .then((data) => setStages(data))
      .catch((error) => console.error("Erro ao buscar estágios:", error));
  }, []);

  const handleSignout = () => {
    navigate('/');
  };

  return (
    <C.MenuContainer>
      <C.Menu>
        <C.MenuItem>
          <C.Logo>
            <img src={Logo_top} alt="Logo" /> 
          </C.Logo>
        </C.MenuItem>
        <C.MenuItem>
          <Link to="/home">Home</Link>
        </C.MenuItem>
        <C.MenuItem>
          <Link to="/Cuidador">Cuidador</Link>
        </C.MenuItem>
      </C.Menu>

      <C.InicialConteiner>
        <C.Header>
          <C.Title>Estágios do Alzheimer</C.Title>
          <C.Text>A doença tem três estágios principais: inicial, moderado e avançado. Conheça os sintomas e saiba o papel dos familiares e/ou cuidadores em cada fase.</C.Text>
        </C.Header>

        {stages.map((stage, index) => (
          <C.Section key={stage.id} style={{ backgroundColor: stage.color }}>
            <C.SectionImage>
              <img
                src={
                  index === 0 ? AlzheimerInicial :
                  index === 1 ? alzheimerMedio :
                  AlzheimerAvancado
                }
                alt={stage.name}
              />
            </C.SectionImage>
            <C.SectionContent>
              <C.SubTitle>{stage.name}</C.SubTitle>
              <C.Text>{stage.description}</C.Text>
              <C.CareTakerTip>
                <strong>Funções do Cuidador:</strong> {stage.caretakerTip}
              </C.CareTakerTip>
            </C.SectionContent>
          </C.Section>
        ))}
      </C.InicialConteiner>
    </C.MenuContainer>
  );
};

export default Cuidador;
