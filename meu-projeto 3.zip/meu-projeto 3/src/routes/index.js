import React, { Fragment } from "react";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import Home from "../pages/Home"; // Corrija o caminho se necessário
import Signin from "../pages/Signin";
import Signup from "../pages/Signup";
import useAuth from "../hooks/useAuth";
import Segunda from "../pages/Semana/Segunda"; 
import Terca from "../pages/Semana/Terca"; 
import Quarta from "../pages/Semana/Quarta"; 
import Quinta from "../pages/Semana/Quinta"; 
import Sexta from "../pages/Semana/Sexta"; 
import Sabado from "../pages/Semana/Sabado"; 
import Domingo from "../pages/Semana/Domingo"; 
import Cuidador from "../pages/Cuidador/Cuidador";

const RouterApp = () => {
    const { signed } = useAuth();

    return (
        <BrowserRouter>
            <Fragment>
                <Routes>
                
                    <Route path="/" element={<Home />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/Signin" element={<Signin />} />
                  
                    <Route path="/home" element={ /*signed ?*/ <Home /> /*: <Navigate to="/" />*/} />
                   <Route path="/cuidador" element={/*signed?*/ <Cuidador/> /*: <Navigate to="/"/>*/}/>
                    <Route path="/Segunda" element={/*signed ?*/ <Segunda /> /*: <Navigate to="/" />*/} />
                    <Route path="/Terca" element={/*signed ?*/ <Terca /> /*: <Navigate to="/" /> */} />
                    <Route path="/Quarta" element={/*signed ?*/ <Quarta /> /*: <Navigate to="/" />*/}/>
                    <Route path="/Quinta" element={/*signed ?*/ <Quinta /> /*: <Navigate to="/" />*/} />
                    <Route path="/Sexta" element={/*signed ? */<Sexta /> /*: <Navigate to="/" />*/} />
                    <Route path="/Sabado" element={/*signed ? */<Sabado /> /*: <Navigate to="/" />*/} />
                    <Route path="/Domingo" element={/*signed ?*/ <Domingo /> /*: <Navigate to="/" />*/} />
               
                    <Route path="*" element={<Navigate to="/" />} />
                </Routes>
            </Fragment>
        </BrowserRouter>
    );
};

export default RouterApp;
