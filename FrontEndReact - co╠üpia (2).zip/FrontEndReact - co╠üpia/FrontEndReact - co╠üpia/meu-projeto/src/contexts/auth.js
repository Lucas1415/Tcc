import React, { createContext, useEffect, useState } from 'react';

export const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        // Restaura o usuário a partir do token salvo (se estiver disponível)
        const userToken = localStorage.getItem("user_token");

        if (userToken) {
            fetch('/api/verify-token', { // Endpoint para verificar o token
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: userToken })
            })
            .then(response => response.json())
            .then(data => {
                if (data.user) {
                    setUser(data.user);
                } else {
                    localStorage.removeItem("user_token");
                }
            })
            .catch(error => console.error("Erro ao verificar token:", error));
        }
    }, []);

    const signin = async (email, password) => {
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                const { user, token } = data;
                localStorage.setItem("user_token", token);
                setUser(user);
            } else {
                return data.message || "E-mail ou senha incorretos";
            }
        } catch (error) {
            console.error("Erro ao tentar fazer login:", error);
            return "Erro ao tentar fazer login";
        }
    };

    const signup = async (email, password) => {
        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                return "Cadastro realizado com sucesso!";
            } else {
                return data.message || "Erro ao tentar se cadastrar";
            }
        } catch (error) {
            console.error("Erro ao tentar se cadastrar:", error);
            return "Erro ao tentar se cadastrar";
        }
    };

    const signout = () => {
        setUser(null);
        localStorage.removeItem("user_token");
    };

    return (
        <AuthContext.Provider value={{ user, signed: !!user, signin, signup, signout }}>
            {children}
        </AuthContext.Provider>
    );
};
