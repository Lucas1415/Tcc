package com.Teste.Teste.Controller;

import com.Teste.Teste.Models.Usuario;
import com.Teste.Teste.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuario") // Define o recurso da API
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    // Retorna todos os usuários
    @GetMapping
    public ResponseEntity<List<Usuario>> getAllUsuarios() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return ResponseEntity.ok(usuarios);
    }

    // Retorna um usuário específico por ID
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getUsuarioById(@PathVariable Integer id) {
        return usuarioRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Deleta um usuário por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Integer id) {
        if (usuarioRepository.existsById(id)) {
            usuarioRepository.deleteById(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    }

    // Cadastro de novo usuário
    @PostMapping
    public ResponseEntity<Usuario> saveUsuario(@RequestBody Usuario newUsuario) {
        // Verifique se o e-mail já existe antes de salvar
        if (usuarioRepository.findByEmail(newUsuario.getEmail()) != null) {
            return ResponseEntity.status(400).body(null);  // 400 Bad Request
        }

        // Salve o novo usuário
        Usuario savedUsuario = usuarioRepository.save(newUsuario);
        return ResponseEntity.status(201).body(savedUsuario); // 201 Created
    }


    // Método para login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Usuario loginData) {
        String email = loginData.getEmail();
        String senha = loginData.getSenha();

        Usuario usuario = usuarioRepository.findByEmail(loginData.getEmail());
        if (usuario != null && usuario.getSenha().equals(senha)) {
            return ResponseEntity.ok("Login bem-sucedido!");
        } else {
            return ResponseEntity.status(401).body("E-mail ou senha incorretos"); // 401 Unauthorized
        }
    }

    // Atualiza um usuário por ID
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> updateUsuario(@RequestBody Usuario updatedUsuario, @PathVariable Integer id) {
        return usuarioRepository.findById(id)
                .map(usuario -> {
                    usuario.setNome(updatedUsuario.getNome());
                    usuario.setEmail(updatedUsuario.getEmail());
                    usuario.setSenha(updatedUsuario.getSenha());
                    Usuario savedUsuario = usuarioRepository.save(usuario);
                    return ResponseEntity.ok(savedUsuario); // 200 OK
                })
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }
}
