package com.Teste.Teste.Controller;




import com.Teste.Teste.Models.Rotina;
import com.Teste.Teste.Repository.RotinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rotina")// para definir o recurso da API

public class RotinaController {
    @Autowired
    private RotinaRepository repository;

    @GetMapping
    public List<Rotina> All(){
        return repository.findAll();
    }

    @GetMapping("/rotina/{id}")
    public Optional<Rotina> one (@PathVariable Integer id){
        return repository.findById(id);
    }

    @DeleteMapping("/rotina/{id}")
    public void delete(@PathVariable Integer id) {repository.deleteById(id);}

    @PostMapping("/rotina")
    public Rotina save(@RequestBody Rotina newRotina){
        return repository.save(newRotina);
    }

    @PostMapping("/rotina/{id}")
    public Rotina replace(@RequestBody Rotina newRotina){
        return repository.save(newRotina);}

    @PutMapping("/Rotina/{id}")
    public Rotina replace(@RequestBody Rotina newRotina, @PathVariable Integer id){
        return repository.findById(id)
                .map(rotina ->{
                    rotina.setId(newRotina.getId());
                    rotina.setSegundaFeira(newRotina.getSegundaFeira());
                    rotina.setTercaFeira(newRotina.getTercaFeira());
                    rotina.setQuartaFeira(newRotina.getQuartaFeira());
                    rotina.setQuintaFeira(newRotina.getQuintaFeira());
                    rotina.setSextaFeira(newRotina.getSextaFeira());
                    rotina.setSabado(newRotina.getSabado());
                    rotina.setDomingo(newRotina.getDomingo());
                    return repository.save(rotina);
                })
                .orElseGet(()->{
                    return repository.save(newRotina);
                });
    }

}
