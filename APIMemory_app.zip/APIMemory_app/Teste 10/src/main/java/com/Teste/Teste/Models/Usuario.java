  package com.Teste.Teste.Models;

import jakarta.persistence.*;

@Entity
@Table(name = "usuarios")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column (nullable = false)
    private String email;

    @Column(nullable = false)
    private String senha;
    @Column(nullable = false)
    private String name; // Adicionando o atributo name

    // Construtores, getters e setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getName() { // Método getName
        return name;
    }

    public void setName(String name) { // Método setName
        this.name = name;
    }
}
