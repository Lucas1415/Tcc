package com.Teste.Teste.Controller;



import com.Teste.Teste.Models.Paciente;
import com.Teste.Teste.Repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/paciente")// para definir o recurso da API

public class PacienteController {
    @Autowired
    private PacienteRepository repository;

    @GetMapping
    public List<Paciente> All(){
        return repository.findAll();
    }

    @GetMapping("/paciente/{id}")
    public Optional<Paciente> one (@PathVariable Integer id){
        return repository.findById(id);
    }

    @DeleteMapping("/paciente/{id}")
    public void delete(@PathVariable Integer id) {repository.deleteById(id);}

    @PostMapping("/paciente")
    public  Paciente save(@RequestBody Paciente newPaciente){
        return repository.save(newPaciente);
    }
    //ID,Nome, Idade, localização
    @PostMapping("/paciente/{id}")
    public Paciente replace(@RequestBody Paciente newPaciente){
        return repository.save(newPaciente);}

    @PutMapping("/paciente/{id}")
    public Paciente replace(@RequestBody Paciente newPaciente, @PathVariable Integer id){
        return repository.findById(id)
                .map(paciente ->{
                    paciente.setId(newPaciente.getId());
                    paciente.setName(newPaciente.getName());
                    paciente.setIdade(newPaciente.getIdade());
                    paciente.setLocalizacao(newPaciente.getLocalizacao());
                    return repository.save(paciente);
                })
                .orElseGet(()->{
                    return repository.save(newPaciente);
                });
    }
}
