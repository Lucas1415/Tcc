package com.Teste.Teste.Controller;
import com.Teste.Teste.Models.Texto;
import com.Teste.Teste.Repository.TextoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TextoController {

    @Autowired
    private TextoRepository textoRepository;

        // Método GET para pegar todos os textos
        @GetMapping
        public List<Texto> getTextos() {
            return textoRepository.findAll();
        }

        // Método POST para adicionar um novo texto
        @PostMapping
        public Texto addTexto(@RequestBody Texto novoTexto) {
            return textoRepository.save(novoTexto);
        }
    }

